import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _MyAppState();
  }
}

class _MyAppState extends State<MyApp> {
  // MyApp({super.key});
  int contador = 10;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tarea 2', // solo para android
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          appBar: AppBar(
            // centerTitle: false,
            title: const Align(
              alignment: Alignment.centerRight,
              child: Text('Contadores'),
            ),
          ),
          body: Center(
            // color: Colors.blue,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              // crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Total:',
                  style: TextStyle(fontSize: 30.0, color: Colors.blue),
                ),
                Text(
                  '$contador',
                  style: TextStyle(fontSize: 28.0, color: Colors.blueGrey), 
                ),
              ],
            ),
          ),
          floatingActionButton: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              FloatingActionButton(
                backgroundColor: Colors.blue,
                child: const Text ('Resta'),
                onPressed: () {
                  contador--;
                  contador=contador-1;

                  //redibuja todos los widgets
                  //que sufrieron cambios
                  setState(() {});
                },
              ),
              const SizedBox(width: 15),
              FloatingActionButton(
                backgroundColor: Colors.blue,
                child: const  Text('Suma'),
                onPressed: () {
                  contador++;
                  contador=contador+1;
         
                  setState(() {});
                },
              ),
            const SizedBox(width: 15),
              FloatingActionButton(
                backgroundColor: Colors.blue,
                child: const Text('Multiplicación'),
                onPressed: () {
                  contador=contador*2;
                
                  setState(() {});
                },
              ),
               const SizedBox(width: 15),
              FloatingActionButton(
                   backgroundColor: Colors.blue,
                child: const Text('División'),
                onPressed: () {
                  contador=contador~/2;
    
                  setState(() {});
                },
              ),
            ],
          )),
    );
  }
}

